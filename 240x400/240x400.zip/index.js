(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[0,0,345,182],[0,184,338,170]]}
];


// symbols:



(lib.iqos = function() {
	this.spriteSheet = ss["index_atlas_P_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.iqos_2 = function() {
	this.spriteSheet = ss["index_atlas_P_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib._18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#404041").s().p("AgEAnQgCgCAAgEIAAgbIgbAAQgCABgCgCQgCgCAAgDQAAgCACgCQACgBACAAIAbAAIAAgbQAAgEACgCQABgBADAAQAEAAABABQABACABAEIAAAbIAbAAQACAAACABQACACABACQgBADgCACQgCACgCgBIgbAAIAAAbQgBAEgBACQgBACgEAAQgDAAgBgCg");
	this.shape.setTransform(24.4,12.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#404041").s().p("AgSA1QgIgFgEgJQgEgHAAgKQAAgHACgGQACgFAFgEQAFgEAGgCQgHgEgEgGQgDgGAAgIQAAgKAEgFQAEgGAHgDQAGgDAHAAQAHAAAHADQAGADAFAGQAEAFAAAKQAAAIgDAGQgEAGgIAEQAHACAFAEQAEAEADAFQACAGAAAHQAAAKgFAHQgEAJgHAFQgIAFgLAAQgKAAgIgFgAgKADQgEADgDAFQgCAGAAAGQAAAHADAFQADAGAEACQAFADAEAAQAGAAADgDQAFgCADgGQADgFgBgHQAAgGgBgGQgCgFgFgDQgFgDgGAAQgFAAgFADgAgLgoQgEAEAAAIQAAAHAEAFQAEAFAHAAQAIAAADgFQAFgFAAgHQAAgIgFgEQgDgEgIgBQgHABgEAEg");
	this.shape_1.setTransform(15.3,10.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#404041").s().p("AAFA4QgCgCAAgEIAAheIgNAAIgFgCQAAAAAAgBQgBAAAAgBQAAAAAAgBQgBgBAAAAQAAgBABgBQAAAAAAgBQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQABgBABAAIAXAAIADABQAAAAABABQAAAAAAAAQAAABAAAAQABABAAABIAABmIgCAGQgCABgEAAQgDAAgCgBg");
	this.shape_2.setTransform(7.6,10.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#404041").ss(1,1,1).p("Ah7hkID3AAQAoAAAAAoIAAB5QAAAogoAAIj3AAQgoAAAAgoIAAh5QAAgoAoAAg");
	this.shape_3.setTransform(16.4,10.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.4,34.8,22.4);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.iqos();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,345,182);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#404041").s().p("AAFAnIAAg2IAAgNIgCADIgMAKIgEgHIATgQIAIAAIAABNg");
	this.shape.setTransform(255.5,23.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#404041").s().p("AAIAoIAAgSIgkAAIAAgIIAkg1IAKAAIAAA0IALAAIAAAJIgLAAIAAASgAAHgYIgDAEIgXAhIAbAAIAAgYIABgRIgBAAIgBAEg");
	this.shape_1.setTransform(249.9,23.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#404041").s().p("AgPAnIAfhEIgpAAIAAgJIAzAAIAAAHIgfBGg");
	this.shape_2.setTransform(243.6,23.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#404041").s().p("AAIAoIAAgSIgkAAIAAgIIAkg1IAKAAIAAA0IALAAIAAAJIgLAAIAAASgAAHgYIgDAEIgXAhIAbAAIAAgYIABgRIgBAAIgBAEg");
	this.shape_3.setTransform(237.3,23.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#404041").s().p("AAIAoIAAgSIgkAAIAAgIIAkg1IAKAAIAAA0IALAAIAAAJIgLAAIAAASgAAHgYIgDAEIgWAhIAaAAIAAgYIABgRIgBAAIgBAEg");
	this.shape_4.setTransform(231,23.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#404041").s().p("AgZAoIAAgIIAVgVIALgNIAEgHIACgIQAAgHgEgDQgEgEgFAAIgJACIgKAGIgFgHQALgJANAAQAKAAAGAGQAHAFAAAKQAAAFgCAFQgCAFgEAEQgDAFgJAIIgQARIAnAAIAAAJg");
	this.shape_5.setTransform(224.7,23.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#404041").s().p("AgTAnIAAgIQAEABAGAAQAIAAAFgDQAGgEADgGQADgHAAgLIgBAAQgGAJgLAAQgLAAgGgGQgGgGAAgLQAAgMAHgHQAHgHALAAQAHAAAGAEQAGAEAEAIQADAIAAAKQAAAtgjAAIgKgBgAgLgaQgEAEAAAJQAAAIAEAEQAEADAHAAQAEAAAEgCQAEgBACgDQACgDAAgEQAAgFgCgFQgCgFgEgCQgEgDgEAAQgHAAgEAFg");
	this.shape_6.setTransform(218.4,23.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#404041").s().p("AgPAnIgKgDIAAgJQAFADAGABIALABQATAAAAgPQAAgOgVAAIgIAAIAAgHIAIAAQAIAAAFgEQAGgEAAgHQAAgGgEgDQgEgDgGAAQgFAAgEABIgLAFIgEgGQAEgEAHgCQAGgCAHAAQALAAAGAFQAGAFAAAJQAAAIgEAEQgEAFgIACIAAAAQAKABAEAEQAFAFAAAIQAAALgIAGQgIAGgNAAIgMgBg");
	this.shape_7.setTransform(212,23.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#404041").s().p("AgPAnIAfhEIgpAAIAAgJIAzAAIAAAHIgfBGg");
	this.shape_8.setTransform(205.8,23.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#404041").s().p("AgPAnIAfhEIgpAAIAAgJIAzAAIAAAHIgfBGg");
	this.shape_9.setTransform(199.5,23.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#404041").s().p("AgZAoIAAgIIAVgVIALgNIAEgHIACgIQAAgHgEgDQgEgEgFAAIgJACIgKAGIgFgHQALgJANAAQAKAAAGAGQAHAFAAAKQAAAFgCAFQgCAFgEAEQgDAFgJAIIgQARIAnAAIAAAJg");
	this.shape_10.setTransform(193.2,23.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#404041").s().p("AgTAfQgGgLAAgUQAAgUAGgKQAGgKANABQANAAAGAKQAHAKAAATQAAAUgHALQgGAKgNAAQgMAAgHgKgAgLgXQgFAHAAAQQAAARAFAIQADAHAIABQAIAAAFgJQADgHAAgRQAAgPgDgIQgFgIgIAAQgIAAgDAIg");
	this.shape_11.setTransform(186.9,23.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#404041").s().p("AAFAnIAAg2IAAgNIgCADIgMAKIgEgHIATgQIAIAAIAABNg");
	this.shape_12.setTransform(179.9,23.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#404041").s().p("AAUAnIAAgkIgnAAIAAAkIgKAAIAAhNIAKAAIAAAhIAnAAIAAghIAKAAIAABNg");
	this.shape_13.setTransform(170.5,23.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#404041").s().p("AgYAnIAAhNIAVAAQAcAAAAAXQAAAMgIAFQgIAHgOAAIgJAAIAAAegAgOAAIAIAAQAKAAAGgDQAFgDAAgJQAAgHgFgEQgFgEgJAAIgKAAg");
	this.shape_14.setTransform(163.4,23.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#404041").s().p("AgVAnIAAhNIArAAIAAAJIghAAIAABEg");
	this.shape_15.setTransform(157.4,23.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#404041").s().p("AgaAeQgJgLAAgTQAAgSAJgLQAKgLAQABQARgBAKALQAJALAAASQAAATgJALQgKALgRAAQgQAAgKgLgAgSgWQgHAHAAAPQAAAPAHAJQAHAIALAAQANAAAGgIQAHgIAAgQQAAgPgGgHQgHgJgNABQgLgBgHAJg");
	this.shape_16.setTransform(149.8,23.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#404041").s().p("AgIAlIADgNIACgOIAKAAIAAACQgCAKgGAPgAgCgXQgCgCAAgEQAAgDACgCQACgCACAAQAHAAAAAHQAAAEgCACQgCACgDAAQgCAAgCgCg");
	this.shape_17.setTransform(141,25.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#404041").s().p("AgMAkQgGgEgDgIQgEgIAAgKQAAgtAjAAIAKABIAAAIIgKgBQgLAAgHAHQgGAIgBAQIABAAQAGgJALAAQALAAAGAHQAGAFAAALQAAAMgHAHQgGAHgMAAQgHAAgGgEgAgGAAQgEACgDADQgCADAAAEQAAAFACAFQACAFAEADQAEACAEAAQAHAAAEgFQAEgEAAgJQAAgIgDgEQgEgDgIAAQgDAAgEABg");
	this.shape_18.setTransform(136.6,23.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#404041").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgBACAAQADAAACABQACADAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_19.setTransform(131.9,27.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#404041").s().p("AAQAeIAAgbIgfAAIAAAbIgKAAIAAg7IAKAAIAAAZIAfAAIAAgZIAKAAIAAA7g");
	this.shape_20.setTransform(127,24.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#404041").s().p("AAXAeIAAgwIgEAMIgPAkIgHAAIgPgkIgCgGIgCgGIAAAwIgJAAIAAg7IAMAAIAPAjIAEAPIAEgNIAPglIAMAAIAAA7g");
	this.shape_21.setTransform(119.4,24.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#404041").s().p("AgNAbQgHgEgDgHQgDgHAAgJQAAgNAHgJQAHgIAMAAQANAAAHAIQAHAJAAANQAAAOgHAJQgHAIgNAAQgHgBgGgDgAgQAAQAAALAEAGQAFAFAHABQAJgBAEgFQAEgGAAgLQAAgKgEgGQgFgFgIgBQgQAAAAAWg");
	this.shape_22.setTransform(111.9,24.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#404041").s().p("AAMAeIgZgeIAAAeIgKAAIAAg7IAKAAIAAAdIAYgdIALAAIgZAdIAbAeg");
	this.shape_23.setTransform(106.2,24.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#404041").s().p("AgHANQADgNACgNIAKAAIAAACQgDALgFANg");
	this.shape_24.setTransform(98.3,27.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#404041").s().p("AgNAnIAAgFIAJgDIAAg9IgJgDIAAgFIAbAAIAAAFIgJADIAAA9IAJADIAAAFg");
	this.shape_25.setTransform(95.2,23.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#404041").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgBACAAQADAAACABQACADAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_26.setTransform(89,27.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#404041").s().p("AAXAeIAAgwIgFAMIgOAkIgHAAIgPgkIgCgGIgCgGIAAAwIgIAAIAAg7IALAAIAQAjIADAPIAEgNIAPglIANAAIAAA7g");
	this.shape_27.setTransform(83.4,24.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#404041").s().p("AgNAbQgHgEgDgHQgDgHAAgJQAAgNAHgJQAHgIAMAAQANAAAHAIQAHAJAAANQAAAOgHAJQgHAIgNAAQgHgBgGgDgAgQAAQAAALAEAGQAFAFAHABQAJgBAEgFQAEgGAAgLQAAgKgEgGQgFgFgIgBQgQAAAAAWg");
	this.shape_28.setTransform(76,24.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#404041").s().p("AAUAnIAAhFIgmAAIAABFIgLAAIAAhNIA6AAIAABNg");
	this.shape_29.setTransform(68.6,23.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#404041").s().p("AgHANQADgNACgNIAKAAIAAACQgDALgFANg");
	this.shape_30.setTransform(60.1,27.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#404041").s().p("AAFAnIAAg2IABgNIgEADIgLAKIgFgHIAVgQIAIAAIAABNg");
	this.shape_31.setTransform(55,23.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#404041").s().p("AAJAoIAAgSIglAAIAAgIIAkg1IAKAAIAAA0IALAAIAAAJIgLAAIAAASgAAHgYIgDAEIgWAhIAbAAIAAgYIAAgRIAAAAIgCAEg");
	this.shape_32.setTransform(49.4,23.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#404041").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgBACAAQADAAACABQACADAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_33.setTransform(44.7,27.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#404041").s().p("AgEAeIAAgzIgTAAIAAgIIAvAAIAAAIIgTAAIAAAzg");
	this.shape_34.setTransform(40.6,24.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#404041").s().p("AgWAcIAAgJQAJADAHABQARAAACgUIgdAAIAAgHIAcAAQAAgJgFgEQgEgEgHAAQgGAAgIACIgDgHIAIgDIAIgBQANAAAHAIQAIAIAAAOQAAAOgIAJQgIAIgNAAQgJAAgHgDg");
	this.shape_35.setTransform(35.1,24.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#404041").s().p("AgHANQADgNACgNIAKAAIAAACQgDALgFANg");
	this.shape_36.setTransform(28,27.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#404041").s().p("AgSAfQgHgLAAgUQAAgUAHgKQAFgKANABQAMAAAIAKQAGAKAAATQAAAUgGALQgHAKgNAAQgMAAgGgKgAgMgXQgDAHAAAQQAAARADAIQAFAHAHABQAJAAADgJQAEgHAAgRQAAgPgEgIQgDgIgJAAQgHAAgFAIg");
	this.shape_37.setTransform(23.6,23.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#404041").s().p("AAFAnIAAg2IABgNIgEADIgKAKIgGgHIAVgQIAIAAIAABNg");
	this.shape_38.setTransform(16.6,23.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#404041").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgBACAAQADAAACABQACADAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_39.setTransform(9.8,27.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#404041").s().p("AAVAoIAAgVIgoAAIAAAVIgKAAIAAgdIAFAAQAHgKAEgMQAEgNAAgPIAeAAIAAAyIAJAAIAAAdgAgFgHQgDALgGAHIAaAAIAAgqIgMAAQgBAMgEAMg");
	this.shape_40.setTransform(5.2,25.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#404041").s().p("AgHANQADgNACgNIAKAAIAAACQgDALgFANg");
	this.shape_41.setTransform(198.8,13.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#404041").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgBACAAQADAAACABQACADAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_42.setTransform(196.1,13.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#404041").s().p("AgTAhQgHgJAAgSQAAgSAGgLQAGgLANgDIAZgFIACAJIgGABIgUAEQgHABgEAHQgEAFAAAMIAAAAQADgEAGgDQAFgCAFAAQAKAAAHAGQAGAHAAAMQAAAOgHAIQgIAHgMABQgMAAgHgKgAgFgCIgGACIgFAHQAAAcARAAQAPAAAAgVQAAgSgOAAQgDAAgEACg");
	this.shape_43.setTransform(191.3,9.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#404041").s().p("AgSAaQgFgEAAgJQAAgRAcAAIAKgBIAAgEQAAgGgDgEQgEgDgGABIgHAAIgIAEIgEgHQAFgDAFgBIAKgCQAKAAAFAGQAGAEAAAKIAAAoIgHAAIgCgJIAAAAQgFAGgEACQgEACgGAAQgJgBgFgEgAAGABQgKABgEACQgFADAAAGQAAAFADADQADACAFAAQAHAAAEgEQAFgFAAgIIAAgFg");
	this.shape_44.setTransform(184.8,10.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#404041").s().p("AAQAeIAAgbIgfAAIAAAbIgKAAIAAg7IAKAAIAAAZIAfAAIAAgZIAJAAIAAA7g");
	this.shape_45.setTransform(178.4,10.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#404041").s().p("AAPAeIAAgYIgOAAIgOAYIgLAAIAQgaQgGgBgEgEQgDgEAAgGQAAgIAFgFQAGgEAJgBIAaAAIAAA7gAgJgSQgDACAAAFQAAAKANAAIAOAAIAAgUIgPAAQgGABgDACg");
	this.shape_46.setTransform(168.6,10.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#404041").s().p("AgSAaQgFgEAAgJQAAgRAcAAIAKgBIAAgEQAAgGgEgEQgDgDgGABIgIAAIgHAEIgEgHQAFgDAFgBIAJgCQAMAAAEAGQAGAEAAAKIAAAoIgHAAIgCgJIAAAAQgFAGgEACQgFACgFAAQgJgBgFgEgAAGABQgKABgEACQgFADAAAGQAAAFADADQADACAFAAQAHAAAEgEQAFgFAAgIIAAgFg");
	this.shape_47.setTransform(162.6,10.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#404041").s().p("AAMAeIgZgeIAAAeIgKAAIAAg7IAKAAIAAAdIAYgdIALAAIgZAdIAbAeg");
	this.shape_48.setTransform(157.3,10.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#404041").s().p("AgOAXQgGgIgBgOQAAgPAIgHQAHgJAMAAIAIABQAFABACABIgCAIQgIgCgFAAQgIAAgEAGQgFAFAAAKQAAALAFAFQAEAGAHAAQAIAAAHgDIAAAJQgFADgKAAQgLgBgIgHg");
	this.shape_49.setTransform(151.4,10.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#404041").s().p("AAQAeIAAgbIgfAAIAAAbIgKAAIAAg7IAKAAIAAAZIAfAAIAAgZIAJAAIAAA7g");
	this.shape_50.setTransform(145.2,10.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#404041").s().p("AgRAXQgHgJAAgNQAAgNAHgJQAHgJALAAQALAAAHAIQAGAHAAAMIAAAFIgnAAQAAAKAFAFQAFAFAIABIAJgBIAKgDIAAAIIgKADIgKABQgMAAgIgIgAgJgRQgEAFgBAHIAdAAQAAgIgEgFQgDgDgHAAQgGAAgEAEg");
	this.shape_51.setTransform(138.6,10.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#404041").s().p("AAQAeIAAgbIgfAAIAAAbIgJAAIAAg7IAJAAIAAAZIAfAAIAAgZIAJAAIAAA7g");
	this.shape_52.setTransform(132,10.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#404041").s().p("AgNAXQgIgIAAgOQABgPAHgHQAHgJAMAAIAIABQAFABADABIgEAIQgHgCgFAAQgIAAgEAGQgEAFgBAKQABALAEAFQAEAGAHAAQAIAAAIgDIAAAJQgHADgJAAQgMgBgGgHg");
	this.shape_53.setTransform(125.9,10.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#404041").s().p("AgRAXQgHgJAAgNQAAgNAHgJQAHgJALAAQALAAAHAIQAGAHAAAMIAAAFIgnAAQAAAKAFAFQAFAFAIABIAJgBIAKgDIAAAIIgKADIgKABQgMAAgIgIgAgJgRQgEAFgBAHIAdAAQAAgIgEgFQgDgDgHAAQgGAAgEAEg");
	this.shape_54.setTransform(120.1,10.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#404041").s().p("AgZArIAAhUIAIAAIABAIIABAAQADgFAEgCQAFgCAFAAQAMAAAGAIQAGAIAAAOQAAAOgGAIQgHAIgLAAQgLAAgGgJIgBAAIAAACIABAIIAAAYgAgMgdQgDAFAAAKIAAACQAAAMADAFQAFAFAHAAQAIAAAEgGQAEgFAAgLQAAgLgEgFQgEgGgIAAQgIAAgEAFg");
	this.shape_55.setTransform(113.8,12.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#404041").s().p("AAUAnIAAhFIgmAAIAABFIgKAAIAAhNIA5AAIAABNg");
	this.shape_56.setTransform(106.2,9.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#404041").s().p("AgHANQADgNACgNIAKAAIAAACQgDALgFANg");
	this.shape_57.setTransform(97.6,13.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#404041").s().p("AgSAaQgFgEAAgJQAAgRAbAAIALgBIAAgEQgBgGgDgEQgDgDgGABIgIAAIgIAEIgDgHQAFgDAFgBIAJgCQAMAAAEAGQAGAEAAAKIAAAoIgHAAIgCgJIAAAAQgFAGgEACQgFACgGAAQgIgBgFgEgAAGABQgJABgFACQgFADAAAGQAAAFADADQADACAFAAQAHAAAEgEQAFgFAAgIIAAgFg");
	this.shape_58.setTransform(93.1,10.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#404041").s().p("AgYAeIAAg7IAaAAQAVABAAAPQAAAFgDADQgDADgGABIAAAAQAIABADADQADAEAAAFQAAAIgGAFQgGAEgLABgAgOAWIAPAAQAPAAgBgKQAAgGgDgCQgEgBgHAAIgPAAgAgOgEIAOAAQAHgBAEgBQADgCAAgFQAAgEgDgCQgEgCgGAAIgPAAg");
	this.shape_59.setTransform(87.3,10.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#404041").s().p("AAMAeIgZgeIAAAeIgKAAIAAg7IAKAAIAAAdIAYgdIALAAIgZAdIAbAeg");
	this.shape_60.setTransform(81.4,10.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#404041").s().p("AgOAXQgGgIAAgOQgBgPAIgHQAHgJAMAAIAJABQAEABACABIgCAIQgIgCgFAAQgIAAgEAGQgFAFABAKQgBALAFAFQAEAGAIAAQAHAAAHgDIAAAJQgGADgIAAQgMgBgIgHg");
	this.shape_61.setTransform(75.6,10.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#404041").s().p("AgNAbQgHgEgDgHQgDgHAAgJQAAgNAHgIQAHgJAMAAQANAAAHAJQAHAIAAANQAAAOgHAJQgHAIgNAAQgHgBgGgDgAgQAAQAAALAEAGQAFAFAHABQAJgBAEgFQAEgGAAgLQAAgKgEgGQgFgFgIAAQgQgBAAAWg");
	this.shape_62.setTransform(69.5,10.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#404041").s().p("AAeAnIAAgvIAAgUIAAAAIgaBDIgHAAIgahEIgBAAIABAWIAAAuIgJAAIAAhNIAPAAIAXA/IAAAAIAZg/IAOAAIAABNg");
	this.shape_63.setTransform(61.1,9.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#404041").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgBACAAQADAAACABQACADAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_64.setTransform(51.8,13.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#404041").s().p("AgRAeIAAg7IAjAAIAAAIIgZAAIAAAzg");
	this.shape_65.setTransform(48.4,10.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#404041").s().p("AgHANQADgNACgNIAKAAIAAACQgDALgFANg");
	this.shape_66.setTransform(41.1,13.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#404041").s().p("AgZAoIAAgIIAVgVIALgNIAEgHIACgIQAAgHgEgDQgEgEgFAAIgJACIgKAGIgFgHQALgJANAAQAKAAAGAGQAHAFAAAKQAAAFgCAFQgCAFgEAEQgDAFgJAIIgQARIAnAAIAAAJg");
	this.shape_67.setTransform(36.6,9.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#404041").s().p("AAFAnIAAg2IABgNIgEADIgKAKIgGgHIAVgQIAIAAIAABNg");
	this.shape_68.setTransform(29.7,9.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#404041").s().p("AAFAnIAAg2IABgNIgEADIgKAKIgGgHIAVgQIAIAAIAABNg");
	this.shape_69.setTransform(23.4,9.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#404041").s().p("AgPAnIgKgDIAAgJQAFADAGABIALABQATAAAAgPQAAgOgVAAIgIAAIAAgHIAIAAQAIAAAFgEQAGgEAAgHQAAgGgEgDQgEgDgGAAQgFAAgEABIgLAFIgEgGQAEgEAHgCQAGgCAHAAQALAAAGAFQAGAFAAAJQAAAIgEAEQgEAFgIACIAAAAQAKABAEAEQAFAFAAAIQAAALgIAGQgIAGgNAAIgMgBg");
	this.shape_70.setTransform(17.7,9.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#404041").s().p("AgZAoIAAgIIAVgVIALgNIAEgHIACgIQAAgHgEgDQgEgEgFAAIgJACIgKAGIgFgHQALgJANAAQAKAAAGAGQAHAFAAAKQAAAFgCAFQgCAFgEAEQgDAFgJAIIgQARIAnAAIAAAJg");
	this.shape_71.setTransform(11.4,9.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#404041").s().p("AAFAnIAAg2IABgNIgEADIgKAKIgGgHIAVgQIAIAAIAABNg");
	this.shape_72.setTransform(4.5,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,261.6,32.9);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#404041").s().p("ADRA5QgHAAgBgIIAAgEQAAgEADgCQADgDACABIAGAAQADgBADADQACACAAAEIAAAEQAAAEgCACQgDACgDAAgAGoA5IgyAAQgTAAgNgNQgNgMgBgTIAAhEIAdAAIAABBQgBAIAGAHQAGAGAJABIApAAQAIABAHgGQAHgGAAgJIAAhDIAdAAIAABEQAAATgNAMQgNANgRAAIgCAAgAgkA5Ig9AAQgTAAgMgNQgOgMgBgTIAAgaQABgSAOgNQAMgNATABIA9AAQATgBAOANQAMANAAASIAAAaQAAATgMAMQgOANgRAAIgCAAgAhqgaQgGAGgCAIIAAAWQABAJAGAGQAHAHAJAAIAxAAQAKAAAGgHQAGgGABgJIAAgTQAAgJgGgGQgFgHgJAAIg0AAIgBAAQgIAAgGAFgAlqA5Ig+AAQgSAAgNgNQgNgMgBgTIAAgaQABgSANgNQANgNASABIA+AAQATgBANANQANANABASIAAAaQgBATgNAMQgNANgSAAIgBAAgAmwgaQgHAGgBAIIAAAWQABAJAGAGQAHAHAJAAIAxAAQAJAAAHgHQAGgGABgJIAAgTQAAgJgGgGQgGgHgJAAIgzAAIgBAAQgIAAgGAFgAkkA0QgFgEgBgGIAAgCQAAgIAGgEIBTg6IhUAAIgEgYIAAgBIB4AAQAHAAAFAFQAEAEAAAGQAAAIgGAEIhTA6IBVAAIAEAZIh4AAIgDAAQgEAAgEgDgADxA3IAAhCQAAgTAOgMQANgNASAAIAWAAIgFAaIgKAAQgJgBgHAGQgGAFgBAJIAABBgACaA3IAAhAQAAgJgFgGQgHgHgIAAIgwAAQgIgBgHAGQgHAGgBAIIAABDIgdAAIAAhEQABgSANgNQANgNASABIA6AAQATgBAOANQANANAAASIAABEg");
	this.shape.setTransform(47,5.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,93.9,11.5);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgeA2IAAhqIA9AAIAAASIgmAAIAAAXIAjAAIAAASIgjAAIAAAcIAmAAIAAATg");
	this.shape.setTransform(101.5,12.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeA2IAAhqIA9AAIAAASIgmAAIAAAXIAjAAIAAASIgjAAIAAAcIAmAAIAAATg");
	this.shape_1.setTransform(91.9,12.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVA2IAAgvIgpAAIAAAvIgXAAIAAhqIAXAAIAAApIApAAIAAgpIAXAAIAABqg");
	this.shape_2.setTransform(80.5,12.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AglA2IAAhqIBDAAIAAASIgsAAIAAAWIAJAAQAUAAALAJQAMAHAAAQQAAAigsAAgAgOAjIAIAAQAKAAAFgEQAGgEAAgHQAAgHgGgDQgFgEgMAAIgGAAg");
	this.shape_3.setTransform(69.2,12.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AglApQgNgOAAgbQAAgaANgOQANgOAYAAQAZAAANAOQANAOAAAaQAAAbgNAOQgNAOgZAAQgXAAgOgOgAgTgaQgHAJAAARQAAASAHAJQAHAJAMAAQAcAAgBgkQAAgjgbAAQgMAAgHAJg");
	this.shape_4.setTransform(56.9,12.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgkA2IAAhqIAiAAQASgBALAJQAKAIAAARQAAARgLAIQgLAJgSAAIgKAAIAAAngAgNgCIAHAAQAJAAAGgEQAFgFAAgIQAAgHgFgEQgEgEgIAAIgKAAg");
	this.shape_5.setTransform(45.4,12.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAiBFIAAgfIhDAAIAAAfIgVAAIAAgyIAIAAQALgUAGgWQAGgVADgYIA+AAIAABXIANAAIAAAygAgKgOQgGASgGAPIAoAAIAAhEIgUAAQgCARgGASg");
	this.shape_6.setTransform(33.3,14.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgkApQgOgOAAgbQAAgaAOgOQANgOAYAAQAYAAANAOQANAOAAAaQAAAbgNAOQgNAOgZAAQgYAAgMgOgAgTgaQgHAJAAARQAAASAHAJQAGAJANAAQAbAAABgkQAAgjgbAAQgNAAgHAJg");
	this.shape_7.setTransform(20.5,12.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAUA2IAAhXIgnAAIAABXIgWAAIAAhqIBTAAIAABqg");
	this.shape_8.setTransform(7.7,12.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,108.8,24.5);


(lib.Символ7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D23648").s().p("Ag6CDIAAhAIgcAAIAAgVIAcAAIAAgfIgcAAIAAgUIAcAAIAAh4QAMgDAOgBQAPgBARgBQAXAAAQAGQARAEAKAKQAKAIAGANQAFANAAAPQAAAPgEAOQgFAMgJAJQgMAMgTAGQgTAHgWAAIgMgBIgMgBIAAAjIBNAAIAAAVIhNAAIAABAgAgPhqIgMACIAABbIAMACIANAAQAbAAAQgMQAQgNAAgYQgBgYgPgLQgOgLgaAAIgQAAg");
	this.shape.setTransform(5.9,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7, new cjs.Rectangle(-2.9,0,17.5,26.3), null);


(lib.Символ6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D23648").s().p("AhyCyQgng9AAh1QAAh5Amg6QAlg7BOAAQBLAAAoA9QAnA9AAB0QAAB5gmA7QgmA7hOAAQhLAAgng9gAhJiQQgXAtAABjQAABlAYAtQAWAsAyABQAygBAYgtQAWgvAAhiQAAhhgWguQgYgugyAAQgyAAgXAtg");
	this.shape.setTransform(132.1,48.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D23648").s().p("Ah2DoIAAgxQAZAJAggBQA0AAAhgUQAhgVASgoQARgoADhBIgEAAQgkA2hKAAQg9gBgkgkQgkglAAhCQAAhIAogqQApgqBDAAQAvAAAkAYQAjAYAUAuQATAvAAA/QAAEQjVAAQgkAAgWgHgAhHihQgYAcAAAzQAAAvAXAZQAWAXAsAAQAbAAAYgMQAXgKAOgUQANgTAAgXQAAgfgMgcQgNgcgXgPQgWgRgdAAQgrABgYAcg");
	this.shape_1.setTransform(94.9,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D23648").s().p("Ah2DoIAAgxQAZAJAggBQA0AAAhgUQAhgVASgoQARgoADhBIgEAAQgkA2hKAAQg9gBgkgkQgkglAAhCQAAhIAogqQApgqBDAAQAvAAAkAYQAjAYAUAuQATAvAAA/QAAEQjVAAQgkAAgWgHgAhHihQgYAcAAAzQAAAvAXAZQAWAXAsAAQAbAAAYgMQAXgKAOgUQANgTAAgXQAAgfgMgcQgNgcgXgPQgWgRgdAAQgrABgYAcg");
	this.shape_2.setTransform(57.8,48.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D23648").s().p("AhcDpQgfgGgdgNIAAg2QAeAPAhAHQAiAIAfAAQB1AAAAhcQAAhRiBAAIgtAAIAAgvIAtAAQA3gBAegXQAfgXAAgpQAAgigXgTQgWgSgmgBQggABgaAIQgaAJghAVIgegnQAdgWAmgNQAlgMAqAAQBCAAAnAeQAmAfgBA1QAAAtgYAdQgaAcgtAKIAAACQA3AHAbAbQAcAdAAAuQAABDguAkQguAjhVABQglAAgfgGg");
	this.shape_3.setTransform(20.3,48.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6, new cjs.Rectangle(0,0,152.8,92.6), null);


(lib.Символ5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#535354").s().p("Ag/BYQgQgQAAgcQAAg8BegDIAiAAIAAgMQAAgXgKgKQgKgLgVAAQgPAAgOAEQgOAFgMAGIgKgYQAPgJARgEQASgFAQABQAkgBASARQARAPAAAjIAACGIgXAAIgHgcIgBAAQgPATgPAGQgOAHgWAAQgdAAgRgPgAATADQghACgQAJQgPAKAAAUQAAAQAJAIQAJAJASAAQAaAAAQgPQAPgPAAgbIAAgSg");
	this.shape.setTransform(30,31.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#535354").s().p("AhLBaIAAgdQAhAPAiAAQAZAAANgIQAOgJAAgQQAAgRgOgIQgOgJgbAAIgbAAIAAgZIAVAAQA3AAAAgfQABgcgtAAQgOAAgMADQgNADgRAHIgLgaQAfgOAmAAQAiAAAUAOQATAOABAYQAAAigmAKIAAACQAXAFAKANQALAMAAATQAAAbgXAPQgWAQgnAAQgrAAgYgNg");
	this.shape_1.setTransform(11,31.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ5, new cjs.Rectangle(0,0,43.1,54.4), null);


(lib.Символ4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#535354").s().p("AA+CXIAAh+IAAgaIABgaIhxCyIgrAAIAAjVIAgAAIAACCIgBAmIgBAKIByiyIAsAAIAADVgAg2hoQgRgPgCgfIAgAAQACATAJAJQAJAHAVABQAUAAAKgJQAKgJACgSIAhAAQgDAfgTAPQgSAOgjAAQglAAgRgOg");
	this.shape.setTransform(235.9,29.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#535354").s().p("ABWBrIAAjVIAjAAIAADVgAh4BrIAAjVIAjAAIAABYIA3AAQApAAAUAPQAUAOAAAfQAAAggVARQgVAQgoAAgAhVBPIAzAAQAyAAAAgjQAAgSgMgIQgKgIgcAAIgzAAg");
	this.shape_1.setTransform(207.5,34);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#535354").s().p("AhaBrIAAjVIBfAAQBQAAAAA2QAAAVgMALQgLAKgXAEIAAACQAcAEANALQAMAMgBAVQAAAfgVAQQgXAQgqAAgAg3BPIA5AAQA2AAAAglQAAgSgNgHQgOgHgcAAIg4AAgAg3gSIA2AAQAbAAAMgHQANgHAAgRQAAgPgMgGQgMgHgXAAIg7AAg");
	this.shape_2.setTransform(181.4,34);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#535354").s().p("AheCdIAAk1IAdAAIAFAdIABAAQAMgRARgIQAQgIAVAAQApAAAYAdQAXAdAAA1QAAAzgXAeQgYAdgqAAQgqAAgXgfIgCAAIABAIIABAbIAABYgAgshtQgPASAAAnIAAAHQAAArAPATQAOATAgAAQAaAAAPgWQAQgVgBgnQABgngQgVQgPgVgbAAQgfAAgOASg");
	this.shape_3.setTransform(157.2,38.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#535354").s().p("Ag/BSQgcgdAAgzQAAgzAageQAZgfArAAQAoAAAZAaQAYAaAAAtIAAAUIiSAAQABAkARATQASATAfAAQARAAAQgDQAPgDAVgJIAAAfQgSAIgQADQgPADgWAAQgvAAgbgdgAgkhBQgPAQgDAdIBtAAQgBgegNgQQgOgPgYAAQgZAAgOAQg");
	this.shape_4.setTransform(133.1,34);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#535354").s().p("AA4BrIAAi3IhvAAIAAC3IgjAAIAAjVIC0AAIAADVg");
	this.shape_5.setTransform(109.3,34);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#535354").s().p("AiQBrIAAjVIAjAAIAAC4IBcAAIAAi4IAiAAIAAC4IBdAAIAAi4IAjAAIAADVg");
	this.shape_6.setTransform(68.5,34);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#535354").s().p("AhEBeQgSgRAAgeQAAhABmgDIAkgCIAAgMQAAgYgKgMQgLgLgXAAQgQAAgPAEQgPAGgOAGIgKgaQAQgJATgFQATgFASAAQAnAAATARQATARAAAmIAACRIgaAAIgHgfIgBAAQgQAUgQAIQgQAHgXAAQggAAgSgRgAAUADQgkACgQAKQgRALAAAWQAAAQAKAJQAKAKATgBQAcAAARgPQARgQAAgeIAAgTg");
	this.shape_7.setTransform(38.6,34.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#535354").s().p("AhjCPIAAkdIBSAAQA4AAAaARQAZARAAAlQAAAZgOARQgOAQgaAFIAAACQAhAGAPAQQAQARAAAdQAAAmgaAVQgbAWguAAgAg/BwIA6AAQAhAAARgNQAQgNAAgbQAAgagRgMQgSgMgiAAIg3AAgAg/gUIA1AAQAgAAAQgLQAPgLAAgZQAAgXgRgLQgRgKgjAAIgvAAg");
	this.shape_8.setTransform(16,30.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ4, new cjs.Rectangle(0,0,250.8,58.5), null);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#404041").s().p("AiFCFIgqgqIiLAAQhHAAgcgbQgXgWAAgqIAAh3QAAgIAGgFQAFgFAJAAICaAAQAhAAAWAFQAcAGAQAQQAXAWAAAqIAAB2IAjAjQAFAFgBAHQAAAHgGAGQgGAFgHABQgHAAgGgFgAmNABQABAdAOANIADADQAPALAeABICbAAIAAhpQgBgdgOgNIgDgDQgNgLgggBIibAAgAoGBbQgSAAAAgUIAAi9QAAgTASAAIABAAQAIAAAFAFQAFAFAAAJIAAC9QAAAJgFAGQgFAFgIAAgAFbBaQgrgBgUgMQgPgKgDgTIAAgDQABgPARAAQAPAAAEALIABADQAFAIAKADQAJADARAAIBUAAQAuAAANgGQALgGAAgVIAAgCQAAgRgHgGQgKgIgfAAIhwAAQgmAAgQgOQgRgNAAggIAAgNQAAgdAUgMQAZgPA/gBIA8AAQAxABAWAMQARAKADATIAAAEQgBAPgRAAQgPAAgEgMIgBgDQgFgJgPgDQgKgCgbAAIg/AAQgnAAgMAGQgMAFAAASIAAAJQAAAOAIAGQAKAHAZAAIBgAAQAvAAATAKQAaAOAAApIAAABQAAAqgjAOQgUAIgtAAgAAlBaQg2AAgcgPQgmgVAAg2IAAgvQAAg2AmgVQAcgPA2AAIA1AAQA3AAAcAPQAmAVAAA2IAAAvQAAA2gmAVQgcAPg3AAgAgZhdQgUANAAAjIAAAsQAAAiAUAOQAQALAjAAIBLAAQAjAAARgLQATgOAAgiIAAgsQAAgjgTgNQgQgMgkAAIhLAAQgjAAgQAMg");
	this.shape.setTransform(53.7,13.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ3, new cjs.Rectangle(0,0,107.5,27.6), null);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.iqos_2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ1, new cjs.Rectangle(0,0,338,170), null);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ12("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(130.8,32.9,1,1,0,0,0,130.8,16.4);

	this.instance_1 = new lib._18("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(242.4,11,1,1,0,0,0,16.4,11);

	this.instance_2 = new lib.Символ11("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(50,7.2,1,1,0,0,0,47,5.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.4,261.6,49.8);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.instance = new lib.Символ10("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(69.4,21.1,1,1,0,0,0,54.4,12.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABfAvQgDgDgBgEQABgEADgDIAWgXIkCAAQgEAAgCgDQgDgDgBgEQABgDADgDQACgDAEAAIECAAIgWgXQgDgDgBgEQABgEADgDQACgDAEAAQAFAAACADIApAoQACADABADQgBAEgCADIgpAoQgCADgFAAQgEAAgCgDg");
	this.shape.setTransform(145.9,20.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D23648").s().p("At1DRIAAmhIbrAAIAAGhg");
	this.shape_1.setTransform(88.6,20.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,177.2,41.8);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Символ 5
	this.instance = new lib.Символ5();
	this.instance.parent = this;
	this.instance.setTransform(21.6,45.2,1,1,0,0,0,21.6,27.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:55.2,alpha:1},14,cjs.Ease.quadInOut).wait(12));

	// Символ 6
	this.instance_1 = new lib.Символ6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(131.4,36.3,1,1,0,0,0,76.4,46.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({y:46.3,alpha:1},14,cjs.Ease.quadInOut).wait(7));

	// Символ 7
	this.instance_2 = new lib.Символ7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(222.4,28,1,1,0,0,0,7.3,11.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({y:38,alpha:1},14,cjs.Ease.quadInOut).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,18,43.1,54.4);


(lib.banner = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Символ13("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(148.8,461.3,1,1,0,0,0,130.8,24.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(194));

	// Слой_14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_173 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_174 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_175 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_176 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_177 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_178 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_179 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_180 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_181 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_182 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_183 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_184 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_185 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_186 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_187 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_188 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_189 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_190 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_191 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_192 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");
	var mask_graphics_193 = new cjs.Graphics().p("EgAbBMdMhMBhMAQgcgdAcgbMBMBhMBQAbgcAdAcMBMABMBQAcAbgcAcMhMBBMBQgOAOgOAAQgNAAgOgOg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(173).to({graphics:mask_graphics_173,x:-291.9,y:-247.9}).wait(1).to({graphics:mask_graphics_174,x:-248,y:-194}).wait(1).to({graphics:mask_graphics_175,x:-206.4,y:-142.9}).wait(1).to({graphics:mask_graphics_176,x:-167,y:-94.5}).wait(1).to({graphics:mask_graphics_177,x:-129.9,y:-48.9}).wait(1).to({graphics:mask_graphics_178,x:-95,y:-6}).wait(1).to({graphics:mask_graphics_179,x:-62.4,y:34.1}).wait(1).to({graphics:mask_graphics_180,x:-32,y:71.4}).wait(1).to({graphics:mask_graphics_181,x:-3.9,y:106}).wait(1).to({graphics:mask_graphics_182,x:22,y:137.8}).wait(1).to({graphics:mask_graphics_183,x:45.6,y:166.8}).wait(1).to({graphics:mask_graphics_184,x:67,y:193.1}).wait(1).to({graphics:mask_graphics_185,x:86.1,y:216.6}).wait(1).to({graphics:mask_graphics_186,x:103,y:237.3}).wait(1).to({graphics:mask_graphics_187,x:117.6,y:255.3}).wait(1).to({graphics:mask_graphics_188,x:130,y:270.5}).wait(1).to({graphics:mask_graphics_189,x:140.1,y:282.9}).wait(1).to({graphics:mask_graphics_190,x:148,y:292.6}).wait(1).to({graphics:mask_graphics_191,x:153.6,y:299.5}).wait(1).to({graphics:mask_graphics_192,x:157,y:303.6}).wait(1).to({graphics:mask_graphics_193,x:158.1,y:305}).wait(1));

	// Слой_13
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#EEEEEE","#BEBEBE"],[0,1],5,28.1,0,5,28.1,362.9).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(173).to({_off:false},0).wait(21));

	// Слой_15 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_1 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_2 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_5 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_6 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_7 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_8 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_9 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_10 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_11 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_12 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_13 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_14 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_15 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_16 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_17 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EgAbAhDMggoggnQgbgcAbgbMAgoggoQAbgbAcAbMAgnAgoQAcAbgbAcMggoAgoQgOANgOAAQgNAAgOgOg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-75.2,y:-120.2}).wait(1).to({graphics:mask_1_graphics_1,x:-57.8,y:-105.2}).wait(1).to({graphics:mask_1_graphics_2,x:-41,y:-90.7}).wait(1).to({graphics:mask_1_graphics_3,x:-24.9,y:-76.9}).wait(1).to({graphics:mask_1_graphics_4,x:-9.6,y:-63.6}).wait(1).to({graphics:mask_1_graphics_5,x:5,y:-51}).wait(1).to({graphics:mask_1_graphics_6,x:18.9,y:-39}).wait(1).to({graphics:mask_1_graphics_7,x:32.1,y:-27.6}).wait(1).to({graphics:mask_1_graphics_8,x:44.6,y:-16.9}).wait(1).to({graphics:mask_1_graphics_9,x:56.4,y:-6.7}).wait(1).to({graphics:mask_1_graphics_10,x:67.4,y:2.8}).wait(1).to({graphics:mask_1_graphics_11,x:77.8,y:11.7}).wait(1).to({graphics:mask_1_graphics_12,x:87.4,y:20}).wait(1).to({graphics:mask_1_graphics_13,x:96.3,y:27.7}).wait(1).to({graphics:mask_1_graphics_14,x:104.5,y:34.8}).wait(1).to({graphics:mask_1_graphics_15,x:112,y:41.3}).wait(1).to({graphics:mask_1_graphics_16,x:118.8,y:47.1}).wait(1).to({graphics:mask_1_graphics_17,x:124.8,y:52.3}).wait(1).to({graphics:mask_1_graphics_18,x:130.2,y:56.9}).wait(1).to({graphics:mask_1_graphics_19,x:134.8,y:60.9}).wait(1).to({graphics:mask_1_graphics_20,x:138.8,y:64.3}).wait(1).to({graphics:mask_1_graphics_21,x:142,y:67.1}).wait(1).to({graphics:mask_1_graphics_22,x:144.5,y:69.2}).wait(1).to({graphics:mask_1_graphics_23,x:146.2,y:70.8}).wait(1).to({graphics:mask_1_graphics_24,x:147.3,y:71.7}).wait(1).to({graphics:mask_1_graphics_25,x:147.6,y:71.9}).wait(169));

	// Слой_5
	this.instance_1 = new lib.Символ4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(149,14.8,0.991,0.991,0,0,0,125.5,29.3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:44.5},14,cjs.Ease.quadInOut).wait(180));

	// Layer 1
	this.instance_2 = new lib.Символ3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(98.4,83.5,1.271,1.271,0,0,0,53.8,13.8);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({_off:false},0).to({y:102.3},15,cjs.Ease.get(1)).wait(176));

	// Слой_6
	this.instance_3 = new lib.Символ8("synched",0,false);
	this.instance_3.parent = this;
	this.instance_3.setTransform(121.8,154.7,0.808,0.808,0,0,0,114.9,46.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},0).wait(180));

	// Слой_10 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_21 = new cjs.Graphics().p("AgbX+I3i3iQgcgcAcgbIXi3iQAbgcAcAcIXiXiQAcAbgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AgbX+I3i3iQgcgcAcgbIXi3iQAbgcAcAcIXiXiQAcAbgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AgbX+I3i3iQgcgcAcgbIXi3iQAbgcAcAcIXiXiQAcAbgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AgbX+I3i3iQgcgcAcgbIXi3iQAbgcAcAcIXiXiQAcAbgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AgbYVI3i3iQgcgcAcgbIXi3iQAbgdAcAcIXiXiQAcAbgcAdI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AgbY/I3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AgbZnI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AgbaMI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AgbavI3i3iQgcgcAcgcIXi3hQAbgdAcAcIXiXhQAcAcgcAdI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AgbbOI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AgbbrI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AgbcFI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_33 = new cjs.Graphics().p("AgbcdI3i3iQgcgcAcgcIXi3hQAbgdAcAcIXiXhQAcAcgcAdI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AgbcxI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AgbdDI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AgbdSI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AgbdfI3i3iQgcgcAcgcIXi3hQAbgdAcAcIXiXhQAcAcgcAdI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AgbdoI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AgbdvI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AgbdzI3i3iQgcgcAcgcIXi3hQAbgcAcAcIXiXhQAcAcgcAcI3iXiQgOAOgOAAQgNAAgOgOg");
	var mask_2_graphics_41 = new cjs.Graphics().p("Agbd1I3i3iQgcgcAcgcIXi3hQAbgdAcAcIXiXhQAcAcgcAdI3iXiQgOAOgOAAQgNAAgOgOg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_2_graphics_21,x:-62,y:119.7}).wait(1).to({graphics:mask_2_graphics_22,x:-44.3,y:130.5}).wait(1).to({graphics:mask_2_graphics_23,x:-27.4,y:140.6}).wait(1).to({graphics:mask_2_graphics_24,x:-11.5,y:150.3}).wait(1).to({graphics:mask_2_graphics_25,x:3.5,y:157.1}).wait(1).to({graphics:mask_2_graphics_26,x:17.6,y:161.3}).wait(1).to({graphics:mask_2_graphics_27,x:30.8,y:165.3}).wait(1).to({graphics:mask_2_graphics_28,x:43.1,y:169}).wait(1).to({graphics:mask_2_graphics_29,x:54.5,y:172.5}).wait(1).to({graphics:mask_2_graphics_30,x:64.9,y:175.6}).wait(1).to({graphics:mask_2_graphics_31,x:74.5,y:178.5}).wait(1).to({graphics:mask_2_graphics_32,x:83.1,y:181.1}).wait(1).to({graphics:mask_2_graphics_33,x:90.9,y:183.5}).wait(1).to({graphics:mask_2_graphics_34,x:97.7,y:185.5}).wait(1).to({graphics:mask_2_graphics_35,x:103.6,y:187.3}).wait(1).to({graphics:mask_2_graphics_36,x:108.6,y:188.8}).wait(1).to({graphics:mask_2_graphics_37,x:112.7,y:190.1}).wait(1).to({graphics:mask_2_graphics_38,x:115.9,y:191}).wait(1).to({graphics:mask_2_graphics_39,x:118.2,y:191.7}).wait(1).to({graphics:mask_2_graphics_40,x:119.5,y:192.1}).wait(1).to({graphics:mask_2_graphics_41,x:120,y:192.3}).wait(153));

	// Слой_7
	this.instance_4 = new lib.Символ9("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(120.2,260.9,1,1,0,0,0,88.5,20.9);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(21).to({_off:false},0).to({y:215.2},20,cjs.Ease.get(1)).wait(153));

	// Слой_12 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_99 = new cjs.Graphics().p("EAKfAm4MghwgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAZAgggAZMgrOAhwQgOALgNAAQgPAAgOgSg");
	var mask_3_graphics_100 = new cjs.Graphics().p("EAIyAm4MghwgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAZAgggAZMgrOAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_101 = new cjs.Graphics().p("EAHIAm4MghvgrNQgZggAggZMArNghwQAggZAYAgMAhxArNQAYAggfAZMgrPAhwQgNALgNAAQgQAAgOgSg");
	var mask_3_graphics_102 = new cjs.Graphics().p("EAFjAm4MghvgrNQgZggAggZMArNghwQAggZAYAgMAhxArNQAYAggfAZMgrPAhwQgOALgMAAQgQAAgOgSg");
	var mask_3_graphics_103 = new cjs.Graphics().p("EAEBAm4MghvgrNQgZggAggZMArNghwQAggZAYAgMAhxArNQAYAggfAZMgrPAhwQgOALgMAAQgQAAgOgSg");
	var mask_3_graphics_104 = new cjs.Graphics().p("EACkAm4MghwgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAZAgggAZMgrOAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_105 = new cjs.Graphics().p("EABKAm4MghwgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAZAgggAZMgrOAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_106 = new cjs.Graphics().p("EgAMAm4MghwgrNQgZggAggZMArNghwQAggZAYAgMAhxArNQAYAggfAZMgrPAhwQgNALgNAAQgQAAgNgSg");
	var mask_3_graphics_107 = new cjs.Graphics().p("EgBeAm4MghwgrNQgZggAggZMArNghwQAggZAYAgMAhxArNQAYAggfAZMgrOAhwQgOALgMAAQgQAAgOgSg");
	var mask_3_graphics_108 = new cjs.Graphics().p("EgCsAm4MghxgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAZAgggAZMgrNAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_109 = new cjs.Graphics().p("EgD3Am4MghxgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAZAgggAZMgrNAhwQgOALgNAAQgPAAgOgSg");
	var mask_3_graphics_110 = new cjs.Graphics().p("EgE+Am4MghwgrNQgZggAggZMArNghwQAggZAYAgMAhxArNQAYAggfAZMgrOAhwQgOALgMAAQgQAAgOgSg");
	var mask_3_graphics_111 = new cjs.Graphics().p("EgFOAnYMghwgrOQgYgfAfgZMArNghwQAggZAYAfMAhxArOQAZAfggAZMgrOAhwQgNALgNAAQgQAAgOgRg");
	var mask_3_graphics_112 = new cjs.Graphics().p("EgFOAn6MghwgrNQgYggAfgZMArNghwQAggZAZAgMAhwArNQAZAgggAZMgrOAhwQgNALgNAAQgQAAgOgSg");
	var mask_3_graphics_113 = new cjs.Graphics().p("EgFOAobMghwgrNQgYggAfgZMArNghwQAggZAZAgMAhwArNQAZAgggAZMgrOAhwQgNALgNAAQgQAAgOgSg");
	var mask_3_graphics_114 = new cjs.Graphics().p("EgFOAo6MghwgrOQgYgfAfgZMArNghwQAggZAYAfMAhxArOQAZAfggAZMgrOAhwQgNALgNAAQgQAAgOgRg");
	var mask_3_graphics_115 = new cjs.Graphics().p("EgFNApWMghxgrOQgZgfAggZMArOghwQAfgZAYAfMAhxArOQAYAfgfAZMgrOAhwQgNALgNAAQgQAAgNgRg");
	var mask_3_graphics_116 = new cjs.Graphics().p("EgFOApwMghwgrNQgZggAggZMArNghwQAggZAZAgMAhwArNQAZAgggAZMgrNAhwQgOALgNAAQgQAAgOgSg");
	var mask_3_graphics_117 = new cjs.Graphics().p("EgFNAqIMghxgrNQgYggAfgZMArOghwQAfgZAZAgMAhwArNQAYAggfAZMgrNAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_118 = new cjs.Graphics().p("EgFNAqfMghxgrOQgZgfAggZMArOghwQAfgZAYAfMAhxArOQAZAfggAZMgrOAhwQgNALgNAAQgQAAgNgRg");
	var mask_3_graphics_119 = new cjs.Graphics().p("EgFNAqzMghxgrOQgZgfAggZMArOghwQAfgZAYAfMAhxArOQAZAfggAZMgrOAhwQgNALgNAAQgQAAgNgRg");
	var mask_3_graphics_120 = new cjs.Graphics().p("EgFNArEMghxgrNQgYggAfgZMArOghwQAfgZAYAgMAhxArNQAYAggfAZMgrNAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_121 = new cjs.Graphics().p("EgFOArUMghwgrOQgZgfAggZMArOghwQAfgZAZAgMAhwArNQAYAggfAZMgrNAhwQgOALgNAAQgQAAgOgSg");
	var mask_3_graphics_122 = new cjs.Graphics().p("EgFNAriMghxgrPQgYgeAfgZMArNghwQAggZAYAfMAhxArOQAYAfgfAZMgrOAhwQgNALgNAAQgQAAgNgRg");
	var mask_3_graphics_123 = new cjs.Graphics().p("EgFOArtMghwgrOQgZgfAggZMArNghwQAggZAZAgMAhwArNQAZAgggAZMgrNAhwQgOALgNAAQgQAAgOgSg");
	var mask_3_graphics_124 = new cjs.Graphics().p("EgFNAr3MghxgrPQgZgfAggYMArOghwQAfgZAZAfMAhwArOQAYAfgfAZMgrNAhwQgOALgNAAQgQAAgNgRg");
	var mask_3_graphics_125 = new cjs.Graphics().p("EgFNAr+MghxgrOQgYggAfgYMArOghwQAfgZAZAgMAhwArNQAYAggfAZMgrNAhwQgOALgNAAQgQAAgNgSg");
	var mask_3_graphics_126 = new cjs.Graphics().p("EgFNAsEMghxgrPQgZgfAggYMArOghwQAfgZAZAfMAhwArOQAYAfgfAZMgrNAhwQgOALgNAAQgQAAgNgRg");
	var mask_3_graphics_127 = new cjs.Graphics().p("EgFOAsHMghwgrPQgZgfAggZMArNghvQAggZAZAfMAhwArOQAZAfggAZMgrNAhwQgOALgNAAQgQAAgOgRg");
	var mask_3_graphics_128 = new cjs.Graphics().p("EgFNAsIMghxgrPQgYgfAfgZMArNghvQAggZAYAfMAhxArOQAYAfgfAZMgrOAhwQgNALgNAAQgQAAgNgRg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(99).to({graphics:mask_3_graphics_99,x:351.1,y:140.7}).wait(1).to({graphics:mask_3_graphics_100,x:340.2,y:152.7}).wait(1).to({graphics:mask_3_graphics_101,x:329.7,y:164.3}).wait(1).to({graphics:mask_3_graphics_102,x:319.5,y:175.4}).wait(1).to({graphics:mask_3_graphics_103,x:309.8,y:186.2}).wait(1).to({graphics:mask_3_graphics_104,x:300.4,y:196.5}).wait(1).to({graphics:mask_3_graphics_105,x:291.4,y:206.4}).wait(1).to({graphics:mask_3_graphics_106,x:282.8,y:215.8}).wait(1).to({graphics:mask_3_graphics_107,x:274.5,y:224.9}).wait(1).to({graphics:mask_3_graphics_108,x:266.7,y:233.5}).wait(1).to({graphics:mask_3_graphics_109,x:259.2,y:241.7}).wait(1).to({graphics:mask_3_graphics_110,x:252.1,y:249.5}).wait(1).to({graphics:mask_3_graphics_111,x:240.3,y:253.7}).wait(1).to({graphics:mask_3_graphics_112,x:227.7,y:257.2}).wait(1).to({graphics:mask_3_graphics_113,x:215.8,y:260.5}).wait(1).to({graphics:mask_3_graphics_114,x:204.7,y:263.5}).wait(1).to({graphics:mask_3_graphics_115,x:194.4,y:266.3}).wait(1).to({graphics:mask_3_graphics_116,x:184.8,y:269}).wait(1).to({graphics:mask_3_graphics_117,x:176,y:271.4}).wait(1).to({graphics:mask_3_graphics_118,x:167.9,y:273.6}).wait(1).to({graphics:mask_3_graphics_119,x:160.7,y:275.6}).wait(1).to({graphics:mask_3_graphics_120,x:154.2,y:277.4}).wait(1).to({graphics:mask_3_graphics_121,x:148.4,y:279}).wait(1).to({graphics:mask_3_graphics_122,x:143.4,y:280.3}).wait(1).to({graphics:mask_3_graphics_123,x:139.2,y:281.5}).wait(1).to({graphics:mask_3_graphics_124,x:135.8,y:282.4}).wait(1).to({graphics:mask_3_graphics_125,x:133.1,y:283.2}).wait(1).to({graphics:mask_3_graphics_126,x:131.2,y:283.7}).wait(1).to({graphics:mask_3_graphics_127,x:130,y:284}).wait(1).to({graphics:mask_3_graphics_128,x:129.7,y:284.1}).wait(66));

	// Слой_11
	this.instance_5 = new lib.Символ14("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(147.5,355.1,1,1,0,0,0,172.5,91);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(99).to({_off:false},0).to({alpha:1},23,cjs.Ease.get(1)).wait(72));

	// Слой_3
	this.instance_6 = new lib.Символ1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(144.1,349.1,1.243,1.243,0,0,0,169,85);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(29).to({_off:false},0).to({scaleX:1,scaleY:1,x:144,alpha:1},28,cjs.Ease.quadInOut).wait(57).to({alpha:0},21,cjs.Ease.get(-1)).wait(59));

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#EEEEEE","#BEBEBE"],[0,1],5,28.1,0,5,28.1,362.9).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(194));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-14.3,300,614.3);


// stage content:
(lib._240x400 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Ayv/PMAlfAAAMAAAA+fMglfAAAg");
	this.shape.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_1
	this.instance = new lib.banner();
	this.instance.parent = this;
	this.instance.setTransform(120,240,0.8,0.8,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110.5,-66.5,471.5,746.5);
// library properties:
lib.properties = {
	id: 'B2B4DAD0E3E41643B552651DF02611BF',
	width: 240,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"./index_atlas_P_.png", id:"index_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B2B4DAD0E3E41643B552651DF02611BF'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;